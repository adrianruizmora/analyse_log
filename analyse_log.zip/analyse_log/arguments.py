import argparse
import sys
import logging

parser = argparse.ArgumentParser(
    "Filters logs and writes output into a new file")
parser.add_argument("-f", "--file", type=str, help="file path")
parser.add_argument("-l", "--logfile", type=str, help="File to log into")
args = parser.parse_args()


logformat = '%(asctime)s %(message)s'
timeformat = '%d/%m/%Y %H:%M:%S'
log = logging
if args.file:
    filename = args.file
else:
    sys.exit("Error : missing command line arguments, try -h for help.")
if args.logfile:
    log.basicConfig(format=logformat, datefmt=timeformat,
                    filename=args.logfile, level=log.INFO)
